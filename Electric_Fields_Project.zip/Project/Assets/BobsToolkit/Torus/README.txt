This collection of scripts will allow you to create and manipulate a torus (donut) shape.

Creating a torus in Unity3D is now just as easy as creating a cube.

To create a torus, go to the menu at top of the Unity window:
1. GameObject
2. 3D Object
3. Torus

Once created, you can keep editing a few variables to create a torus to your liking.

Duplicates:
When duplicating a torus, both instances will use the same mesh. To start with a new mesh, click the "New mesh" button in the Torus inspector.