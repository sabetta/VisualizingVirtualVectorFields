using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Charges : MonoBehaviour
{
    public bool backGround = false;
    public float charge = 0;

}
